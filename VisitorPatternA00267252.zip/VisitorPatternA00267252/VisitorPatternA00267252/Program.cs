﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

interface Visitor
{
    void visit(EmployeeDetail ed);
}


interface Visitable
{
    void accept(Visitor visitor);
}
class EmployeeDetail : Visitable
{
    private string name;
    private double salary;

    public EmployeeDetail(double m, string t)
    {
        name = t;
        salary = m;
    }


    //taxOnSalary and yearTakeHome functions has a feature accept taking
    //an argument of type VISITOR  to select, through dynamic binding

    public double SALARY //function salary
    {
        get { return salary; }
    }

    public double taxOnSalary()
    {
        if (salary == 0) return 0;
        double res;
        res = 0.1 * salary;
        return res;
    }

    public double yearTakehome()
    {
        double Takehome = salary - taxOnSalary();
        return Takehome;
    }
    public void print_details(string name)
    {
            Console.WriteLine("\n Breakdown of " + name + " yearly salary");
    }

    public void accept(Visitor visitor)
    {
        visitor.visit(this);
    }

   
}
//The new functions added to calclate the allowances just introduced by the company for staff.,
//The new function to cal allowance in the more function request to visit the empolyee details to get there salary and now add 
//d allowances to it


//On the visitor side, you has a visit procedure so it can use it to communicate to the employee detail for permission to access its function
class newFunctions : Visitor
{
    EmployeeDetail sub;
    public void visit(EmployeeDetail ed)
    {
        this.sub = ed;
    }

    public double houseAllowance()
    {
        if (sub.SALARY == 0) return 0; //Call the salary function in the targeted application inorder to get the house allowance percentage value
        double res = sub.SALARY;
        res = (0.04 * res);
        return res;
    }
    public double wardrobeAllowance()
    {
        if (sub.SALARY == 0) return 0; //Call the salary function in the targeted application inorder to get the wardrobe allowance percentage value
        double res = sub.SALARY;
        res = (0.03 * res);
        return res;
    }
    public double transportAllowance()
    {
        if (sub.SALARY == 0) return 0; //Call the salary function in the targeted application inorder to get the transport allowance percentage value
        double res = sub.SALARY;

        res = (0.04 * res);
        return res;
    }

    public double yearNewTakehome()
    {

        double resultAfterTax = sub.yearTakehome();
        double TotalAllowance = (houseAllowance() + wardrobeAllowance() + transportAllowance());
        double newTakehome = resultAfterTax + TotalAllowance;
        return newTakehome;
    }
}

public class QVisitor
{
    public static void Main(string[] args)
    {
        string[] k = {"Jude", "Jane", "Tom", "Kitty" };
        Console.WriteLine( "Calculate the salary of "+ string.Join(",", k) + " respectively");
        Console.WriteLine("Enter the Salary for the Staffs");
        double[] m = new double[4];
        for (int i = 0; i < m.Length; i++)
        {
            double count = double.Parse(Console.ReadLine());
            m[i]  = count;
        }

            for (int i = 0; i < m.Length; i++)
            {

            EmployeeDetail s = new EmployeeDetail(m[i], "");
            if (i == 0)
                s.print_details(k[0]);
            if (i == 1)
                s.print_details(k[1]);
            if (i == 2)
                s.print_details(k[2]);
            if (i == 3)
                s.print_details(k[3]);
         
            Console.WriteLine("Total Salary without Tax :" + s.SALARY);
                Console.WriteLine("Tax Deducted from Salary :" + s.taxOnSalary());
                Console.WriteLine("Total Salary after Tax deduction :" + s.yearTakehome());
            newFunctions nf = new newFunctions();
            s.accept(nf);
            Console.WriteLine("Added House Allowance Salary : " + nf.houseAllowance());
            Console.WriteLine("Added Transport Allowance Salary : " + nf.transportAllowance());
            Console.WriteLine("Added Warddrobe Allowance Salary : " + nf.wardrobeAllowance());
            Console.WriteLine("Total Salary with Allowances : " + nf.yearNewTakehome());

        }
        Console.ReadLine();

    }
}


